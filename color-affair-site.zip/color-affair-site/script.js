
document.getElementById('contactForm').addEventListener('submit', function(event) {
  event.preventDefault();
  document.getElementById('formResponse').innerText = "Message sent successfully!";
  this.reset();
});
